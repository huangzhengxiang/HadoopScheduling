#pragma once
#include "ResourceScheduler.h"
#include<fstream>

void generator(ResourceScheduler&, int, int);

void WriteData(string fileName, string text);