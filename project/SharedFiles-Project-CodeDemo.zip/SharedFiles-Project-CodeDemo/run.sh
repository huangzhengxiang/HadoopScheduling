sudo cmake .
make
cd cppFiles
./run